import express from "express";

import cors from "cors";

//Importa o modulo fs(file system) este modulo permite ler e escrever arquivos utilizando JavaScript
import fs from "fs";

//importa a conexão criada com o Firebase
import db from "./firebase.js";

import {
  ref,
  push
} from "firebase/database";

const app = express();

app.use(cors());

//permite que a API receba e interprete dados no formato JSON enviados pelo React
app.use(express.json());

let historico = [];

//verifica se o arquivo historico.json existe, caso exista ele lê o conteúdo do arquivo e armazena na variável historico
if (fs.existsSync("api/historico.json")) {
  const dadosArquivo = fs.readFileSync(
    "api/historico.json",
    "utf-8");
  try {
    if (dadosArquivos.trim() !== "") {

      //converte o JSON do arquivo para um array em JavaScript
      historico = JSON.parse(dadosArquivo);
    }else {
      historico = [];
    }
}catch (error) {
  historico = [];
}
}

app.get("/historico", (req, res) => {
  res.json(historico);
});

app.post("/historico", (req, res) => {
  historico.push(req.body);

  //cria uma referência para o nó "historico" no Firebase
  //caso não exista, ele será criado automaticamente
  const referenciaFirebase = ref(
    db, "historico"
  );
  // Salva uma copia dos dados tambem no Firebase
  await push(
    referenciaFirebase, 
    req.body);

  // Converte o array JavaScript para JSON
  //o numero 2 deixa o arquivo organizado e legivel
  const historicoJSON = JSON.stringify(
    historico, 
    null, 
    2
  );

  //salva os dados atualizados no arquivo historico.json
  //assim os registros permanecem armazenados mesmo após desligar o servidor
  fs.writeFileSync(
    "./api/historico.json",
    historicoJSON
  );
  //retorna uma resposta para o React informando que o registro foi salva com sucesso
  res.json({ message: "Consulta salva" });
});

//inicialização do servidor

app.listen(3000, () => {
  console.log("Servidor iniciado na porta 3000");
});
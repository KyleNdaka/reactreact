//conectando o banco api com o banco do Firebase

//importa a função responsável por inicializar o Firebase
import { initializeApp } from "firebase/app";

//importa a função responsável por conectar o realtime database
import { getDatabase } from "firebase/database";

//configurações do projeto no Firebase
//
//essas informações são geradas automaticamente pelo Firebase quando registramos a nossa aplicação
//
//elas funcionam como um endereço que 
// permite que a nossa aplicação encontre e se conecte com o banco de dados na nuvem
const firebaseConfig = {
    //identificador único do aplicativo
  apiKey: "AIzaSyDNv2YRLIXtoDuPQWDN1nsMmswYHST70oU",
  //domínio de autenticação do projeto
    authDomain: "previ-61c4e.firebaseapp.com",
    //endereço do realtime database
    databaseURL: "https://previ-61c4e-default-rtdb.asia-southeast1.firebasedatabase.app",
    //identificador do projeto Firebase
    projectId: "previ-61c4e",
    //servidor de armazenamento de arquivos
    storageBucket: "previ-61c4e.firebasestorage.app",
    //identificador responsável pela troca de mensagens
    messagingSenderId: "890595214039",
    //identificador unico da aplicação web
    appId: "1:890595214039:web:d3768376e23d152a436692",
    //identificador utilizado pelo google analytics
    measurementId: "G-GX40MZLLG3"
}

const app = initializeApp(firebaseConfig);

//cria uma conexão com o realtime database a partir deste objeto sera possível: 
// ler dados 
// salvar dados, 
// atualizar dados e 
// excluir dados do banco
const db = getDatabase(app);

//exporta a conexão para que ele possa ver
export default db;